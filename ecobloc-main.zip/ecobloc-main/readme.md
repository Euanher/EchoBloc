# Vanilla JavaScript App

This repo is used as a starter for a _very basic_ HTML web application using no front-end frameworks.